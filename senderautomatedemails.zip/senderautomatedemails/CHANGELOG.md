# CHANGE LOG

1.0.2
============
* Fixed Product to Cart Data mapping

1.0.1
============
* Fix product block json encoding

1.0.0
============
* Initial release