# CHANGE LOG

1.0.1
============
* Fix product block json encoding

1.0.0
============
* Initial release