# CHANGE LOG

1.0.6
============
* Added support for Prestashop version 1.6.0.5 to 1.7.4.4
* Added discount in sender json for product import
* Bug fixes

1.0.5
============
* Fixed array to string conversion bug in hookDisplayOrderConfirmation

1.0.4
============
* Changed cart convert hook

1.0.3
============
* Added better customer syncing
* Improved product import security
* Redirecting to checkout page when recovering cart
* Using product thumbnail image when syncing

1.0.2
============
* Fixed Product to Cart Data mapping

1.0.1
============
* Fix product block json encoding

1.0.0
============
* Initial release