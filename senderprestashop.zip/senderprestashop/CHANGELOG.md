# CHANGE LOG

1.0.1
============
 * Fixed CART SUMMARY hook bug
 * Changed Cart total method to getOrderTotal in synCarts